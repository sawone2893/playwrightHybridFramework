import { Given, When, Then } from "@cucumber/cucumber";
import { FactoryRegistries } from "../../src/factory/factoryRegistry";
import { DateManager } from "../../src/utilities/dateManager";

const outstandingAnalysisVWFPage = FactoryRegistries.getOutstandingAnalysisVWFPage();
const testExecutor=FactoryRegistries.getTestExecutor();

/*Example:
* When I perform edit set for "Sample Type" "Set 1" with values "OIL;Assign~COOLANT;Assign"
 */
When('I perform edit set for {string} {string} with values {string}',async(editSetType: string,setName: string,sampleTypeAnalysisNames: string)=>{
    await outstandingAnalysisVWFPage.performEditSetForSampleTypeOrAnalysis(editSetType,setName,sampleTypeAnalysisNames);
});

/*Example:
* When I verify outstanding Analysis Data table for date "0"
 */
When('I verify outstanding Analysis Data table for date {string}',async(rowData:string)=>{
    await outstandingAnalysisVWFPage.validateOutsandingAnalysisTableData(rowData);
});