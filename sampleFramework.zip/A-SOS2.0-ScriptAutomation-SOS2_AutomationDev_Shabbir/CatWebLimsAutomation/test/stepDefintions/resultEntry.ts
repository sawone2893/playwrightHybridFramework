import { Given, When, Then } from "@cucumber/cucumber";
import { FactoryRegistries } from "../../src/factory/factoryRegistry";

const resultEntryPage = FactoryRegistries.getResultEntryPage();
