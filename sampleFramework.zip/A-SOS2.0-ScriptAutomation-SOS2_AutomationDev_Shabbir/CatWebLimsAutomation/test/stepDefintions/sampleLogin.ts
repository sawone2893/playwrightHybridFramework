import { Given, When, Then } from "@cucumber/cucumber";
import { FactoryRegistries } from "../../src/factory/factoryRegistry";
import { FileHandler } from "../../src/utilities/fileHandler";

const sampleLoginPage = FactoryRegistries.getSampleLoginPage();

/*Example:
* When I open sample login template id as "Z_SIMPLE_TESTING"
 */
When('I open sample login template id as {string}',async(templateIdName:string)=>{
    await sampleLoginPage.openTemplate(templateIdName);
  });

/*Example:
* When I enter sample login template summary details as "Dealer,B030~Lab,A100~Text Id,SAMPLE1AUTO1~Process Date,0~Sample Type,OIL~Equipement Component,XYZ~Serial Number,123456~Equipment Number,4234234"
 */
When('I enter sample login template summary details as {string}',async(templateFieldValuedetails:string)=>{
  await sampleLoginPage.enterSampleLoginTemplateSummaryDetails(templateFieldValuedetails);
});

/*Example:
* When I add replicate "1" for sample "SAMPLE1" and test or analysis "H2O"
 */
When('I add replicate {string} for sample {string} and test or analysis {string}',async(noOfReplicates:string,sampleName:string,testAnalysisName:string)=>{
  const sampleNameTemp = await FileHandler.getKeyValue(sampleName) || sampleName;
  const testAnalysisNameTemp = await FileHandler.getKeyValue(testAnalysisName) || testAnalysisName;
  await sampleLoginPage.editTestsAddReplicates(noOfReplicates,sampleNameTemp,testAnalysisNameTemp);
});