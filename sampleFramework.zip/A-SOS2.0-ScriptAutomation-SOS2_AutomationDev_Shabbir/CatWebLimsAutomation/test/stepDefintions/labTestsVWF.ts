import { Given, When, Then } from "@cucumber/cucumber";
import { FactoryRegistries } from "../../src/factory/factoryRegistry";
import { DateManager } from "../../src/utilities/dateManager";

const labTestsVWFPage = FactoryRegistries.getLabTestsVWFPage();
const testExecutor=FactoryRegistries.getTestExecutor();

/*Example:
* When I select Dealers "B030   ALTORFER INC.;Assign~D600   PIPELINE MACHINERY;Assign" from Sample Criteria
 */
When('I select Dealers {string} from Sample Criteria',async(dealersNames: string)=>{
    await labTestsVWFPage.selectDealersFromSampleCriteria(dealersNames);
});

/*Example:
* When I enetered start date as "0" end date as "6" in Sample Criteria
 */
When('I enetered start date as {string} end date as {string} in Sample Criteria',async(startDateValue: string,endDateValue: string)=>{
    await labTestsVWFPage.enterStartEndDate(startDateValue,endDateValue);
});

/*Example:
* When I Verify Lab Test Data table dealer/lab/batch "B030" date "0" is displayed in "LabTestTableData" with values "1,1"
 */
When('I Verify Lab Test Data table {string} {string} date {string} is displayed in {string} with values {string}',async(dealerLabBatchValue:string,dateValue:string,locatorIdentifier:string,param:string)=>{
    const value=await DateManager.getDaysOut(Number(dateValue), "DD-MM-YY");
    await testExecutor.executeAction({action:"VerifyElementText",locator:await testExecutor.getLocator(locatorIdentifier,param),value:dealerLabBatchValue+" "+value}); 
});