import { Given, When, Then } from "@cucumber/cucumber";
import { FactoryRegistries } from "../../src/factory/factoryRegistry";
import { FileHandler } from "../../src/utilities/fileHandler";
import { randomNum } from "../../src/utilities/commonUtil";

const folderManagerPage = FactoryRegistries.getFolderManagerPage();
const testExecutor=FactoryRegistries.getTestExecutor();

/*Example:
 * When I create new folder with name "FOLDER1234", template "SAMPLE_INPROGRESS", owner "RAYEES", description "Creating new folder"
 */
When("I create new folder with name {string}, template {string}, owner {string}, description {string}",async (folderName: string,templateName: string,ownerName: string,description: string) => {
    const folderNameTemp = `${folderName}_${randomNum()}`; 
    await FileHandler.setKeyValue(folderName, folderNameTemp);
    await folderManagerPage.createNewFolder(folderNameTemp,templateName,ownerName,description);
});

/*Example:
* When I select date range from "comboxbox" as "Next 2 Days (Inclusive)"
 @dateSelectionType:comboxbox or textfield
 */
When('I select date range from {string} as {string}',async(dateSelectionType:string,dateRangeValue:string)=>{
  if(dateSelectionType==="combobox"){
    await folderManagerPage.selectDateRangeFromComboboxDropdown(dateRangeValue);
  }else{
    const datesValues=dateRangeValue.split(",")
    await folderManagerPage.enterStartEndDate(datesValues[0],datesValues[1]);
  }
  
});

/*Example:
* When I select "sample type" as "OIL" for creating new folder
  When I select "dealers" as "N030,B170" for creating new folder
 */
When('I select {string} as {string} for creating new folder',async(propertyName:string,propertyValue: string)=>{
  if(propertyName ==="sample type"){
    await folderManagerPage.selectSampleTypeForFolder(propertyValue);
  }else if(propertyName ==="dealers"){
    await folderManagerPage.selectDealersFromMultiSelect(propertyValue);
  }
});

/*Example:
* When I add analysis "ANALYSIS1234" for analysis type "OIL" in folder
 */
When('I add analysis {string} for analysis type {string} in folder',async(analysisName: string, analysisType: string)=>{
  if(analysisName.includes(",")){
    const analysisValues=analysisName.split(",");
    await folderManagerPage.addAnalysisInFolder(`${await FileHandler.getKeyValue(analysisValues[0]) || analysisValues[0]},${await FileHandler.getKeyValue(analysisValues[1]) || analysisValues[1]}`,analysisType);
  }else{
    await folderManagerPage.addAnalysisInFolder(await FileHandler.getKeyValue(analysisName) || analysisName,analysisType);
  }
  
});

/*Example:
* When I open created folder named "AUTO_FOLDER1"
 */
When('I open created folder named {string}',async(folderName: string)=>{
  const folderNameTemp = await FileHandler.getKeyValue(folderName) || folderName;
  await folderManagerPage.openCreatedFolder(folderNameTemp);
});

/*Example:
* When I "add" group objects property "Sample.Text Id,Sample.X Dealer Customer,Sample.X Asset Component,Sample.X Asset Nickname,Sample.X Asset Serial Number"
 */
When('I {string} group objects property {string}',async(addRemoveProperty:string,multiSelectOptionsName: string)=>{
  await folderManagerPage.addRemoveGroupObjects(addRemoveProperty,multiSelectOptionsName);
});


 /*Example:
* When I "VerifyElementText" is "true" for cell In frozen/fixed table by row as "Sample Id" and col as "Lab Note"
 */
When('I {string} is {string} for cell In frozen\\/fixed table by row as {string} and col as {string}',async (action:string, textToBeEnter: string, row: string, column: string)=>{
  await testExecutor.executeAction({action:action, value:textToBeEnter, locator:await folderManagerPage.cellLocatorByColAndRowForFrozenPaneTable(column, row)});
});

/*Example:
* Then I verify group object property "Text Id" with value "Sample12343" having sample "Sample12343"
 */
Then('I verify group object property {string} with value {string} having sample {string}',async(propertyName:string,propValues:string,sampleName:string)=>{
  await folderManagerPage.verifyObjectGroupPropertyData(propertyName,propValues,sampleName);
});