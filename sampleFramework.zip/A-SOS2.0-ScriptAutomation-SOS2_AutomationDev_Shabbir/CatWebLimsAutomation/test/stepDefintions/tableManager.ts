import { Given,When, Then } from "@cucumber/cucumber";
import {FactoryRegistries} from '../../src/factory/factoryRegistry'
import { FileHandler } from "../../src/utilities/fileHandler";
import { randomNum } from "../../src/utilities/commonUtil";

const tableManagerPage = FactoryRegistries.getTableManagerPage();

/*Example:
* When I open table with name "Analysis"
 */
When('I open table with name {string}',async(tableName:string)=>{
    await tableManagerPage.openTable(tableName);
});

/*Example:
* When I add new analysis with name "ANALYSIS123"
 */
When('I add new analysis with name {string}',async(analysisName:string)=>{
    const analysisNameTemp = `${analysisName}_${randomNum()}`; 
    await FileHandler.setKeyValue(analysisName, analysisNameTemp);
    await tableManagerPage.addAnalysis(analysisNameTemp);
});

/*Example:
* When I select analysis field "Analysis Type" with value "PHYSICAL" from dialogMainView "Analysis Types"
 */
When('I select analysis field {string} with value {string} from dialogMainView {string}',async(analysisFieldName:string,analysisFieldValue:string,dialogMainViewName:string)=>{
    if(analysisFieldName!=="Sample Type"){
        await tableManagerPage.selectAnalysisFields(analysisFieldName,analysisFieldValue,dialogMainViewName);
    }else{
        await tableManagerPage.selectSampleType(analysisFieldValue,dialogMainViewName);
    }
    
});

/*Example:
* When I select configure option name "Component"
 */
When('I select configure option name {string}',async(configureOptionName:string)=>{
    await tableManagerPage.selectConfigureOptions(configureOptionName);
});

/*Example:
* When I "Add" component with name "COMP_NUMERIC"
 */
When('I {string} component with name {string}',async(addRenameOperation:string,componentName:string)=>{
    await tableManagerPage.addRenameComponent(addRenameOperation,componentName);
});

/*Example:
* When I select component configure data type as "Numeric"
 */
When('I select component configure data type as {string}',async(dataTypeName:string)=>{
    await tableManagerPage.selectComponentConfigureDataType(dataTypeName);
});

/*Example:
* When I "checked" component checkbox as "reportable"
 */
When('I {string} component checkbox as {string}',async(status:string,checkboxName:string)=>{
    await tableManagerPage.selectComponentCheckbox(status,checkboxName);
});

/*Example:
This supports Numeric and Calculated
* When I add "Numeric" properties for component "<componentName1>" as aliasName "COMP_N", units "KM", roundResultValue "Decimal Places w/0.5 Up", decimalPlaces "2", sigFigs "1", formatCalculation "WEAR_LIMIT"
 */
When('I add {string} properties for component {string} as aliasName {string}, units {string}, roundResultValue {string}, decimalPlaces {string}, sigFigs {string}, formatCalculation {string}',async(dialogMainViewName:string,componentName:string,aliasName:string,units:string,roundResultValue:string,decimalPlaces:string,sigFigs:string,formatCalculation:string)=>{
    await tableManagerPage.addComponentNumericOrCalculatedProperties(dialogMainViewName,componentName,aliasName,units,roundResultValue,decimalPlaces,sigFigs,formatCalculation);
});

/*Example:
This supports List properties
* When I add List properties for component "<componentName2>" as aliasName "COMP_L", listName "C_FOAM", formatCalculation "WEAR_LIMIT"
 */
When('I add List properties for component {string} as aliasName {string}, listName {string}, formatCalculation {string}',async(componentName: string,aliasName: string,listName: string,formatCalculation: string)=>{
    await tableManagerPage.addComponentListProperties(componentName,aliasName,listName,formatCalculation);
});

/*Example:
This supports Text properties
* When I add Text properties for component "<componentName3>" as aliasName "COMP_T", formatCalculation "WEAR_LIMIT"
 */
When('I add Text properties for component {string} as aliasName {string}, formatCalculation {string}',async(componentName: string,aliasName: string,formatCalculation: string)=>{
    await tableManagerPage.addComponentTextProperties(componentName,aliasName,formatCalculation);
});


/*Example:
* When I changed order "Move Down;2" for component "COMP_NUMERIC"
 */
When('I changed order {string} for component {string}',async(orderValue:string,componentName:string)=>{
    await tableManagerPage.changeComponentOrder(componentName,orderValue);
});

/*Example:
* When I open created analysis named "ANA1_AUTO"
 */
When('I open created analysis named {string}',async(analysisName: string)=>{
    const analysisNameTemp = await FileHandler.getKeyValue(analysisName) || analysisName;
    await tableManagerPage.openExistingAnalysis(analysisNameTemp);
  });

/*Example:
* When I configure group name "FmjEX_Automation" for user "RAYEES"
 */
When('I configure group name {string} for user {string}',async(groupName: string,userName: string)=>{
    await tableManagerPage.configureUsersGroupName(groupName,userName);
  });

