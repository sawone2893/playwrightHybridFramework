import { When } from "@cucumber/cucumber";
import {FactoryRegistries} from '../../src/factory/factoryRegistry'

const visualWorkflowPage = FactoryRegistries.getVisualWorkflowPage();

/*Example:
* Then I verify the start date and end date for "Last 7 days" selection for Lab Work VWF
 */
When('I verify the start date and end date for {string} selection for Lab Work VWF', async(selectedRange:string)=>{
    await visualWorkflowPage.validateStartEndDate(selectedRange);
});