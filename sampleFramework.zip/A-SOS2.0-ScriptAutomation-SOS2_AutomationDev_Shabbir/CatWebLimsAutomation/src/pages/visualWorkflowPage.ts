import { FactoryRegistries } from "../factory/factoryRegistry";
import { DateManager } from "../utilities/dateManager";

export class VisualWorkflowPage {
  private commonPage = FactoryRegistries.getCommonPage();

  pageObject = {};

  async validateStartEndDate(selectedRange: string) {
    let startDate = await global.actionDriver.getElementText(
      this.commonPage.pageObject.tagWithAttribute(
        "span",
        "id",
        "vwwork_main_dfromdate1_span"
      )
    );
    let endDate = await global.actionDriver.getElementText(
      this.commonPage.pageObject.tagWithAttribute(
        "span",
        "id",
        "vwwork_main_dtodate1_span"
      )
    );
    if(selectedRange == "Last 7 days") {
      global.expect_(startDate).to.be.equal(await DateManager.getDaysOut(-7, "MM/DD/YYYY"));
      global.expect_(endDate).to.be.equal(await DateManager.getDaysOut(0, "MM/DD/YYYY"));
    } else if(selectedRange == "Last 3 days") {
      global.expect_(startDate).to.be.equal(await DateManager.getDaysOut(-3, "MM/DD/YYYY"));
      global.expect_(endDate).to.be.equal(await DateManager.getDaysOut(0, "MM/DD/YYYY"));
    } else if(selectedRange == "Last 30 days") {
      global.expect_(startDate).to.be.equal(await DateManager.getDaysOut(-30, "MM/DD/YYYY"));
      global.expect_(endDate).to.be.equal(await DateManager.getDaysOut(0, "MM/DD/YYYY"));
    } else if(selectedRange == "Today") {
      global.expect_(startDate).to.be.equal(await DateManager.getDaysOut(-1, "MM/DD/YYYY"));
      global.expect_(endDate).to.be.equal(await DateManager.getDaysOut(0, "MM/DD/YYYY"));
    }
  }
}