import { FactoryRegistries } from "../factory/factoryRegistry";

export class TableManagerPage {
  private commonPage = FactoryRegistries.getCommonPage();

  pageObject = {};

  async openTable(tableName: string) {
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.tagWithAttribute("img", "title", "Open Table")
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Select Table",
        "td",
        tableName
      )
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Select Table",
        "button",
        "OK"
      )
    );
  }

  async addAnalysis(analysisName: string) {
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.tagWithAttribute("img", "title", "New")
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        "New Entry Dialog",
        "input",
        "id",
        "entryField"
      ),
      analysisName
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "New Entry Dialog",
        "button",
        "OK"
      )
    );
    await global.actionDriver.waitForElement(2);
  }
  async selectAnalysisFields(
    analysisFieldName: string,
    analysisFieldValue: string,
    dialogMainViewName: string
  ) {
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.formFieldWithIcon(
        "div",
        analysisFieldName,
        "search"
      )
    );

    if (analysisFieldValue.includes(";")) {
      const values = analysisFieldValue.split(";");
      await global.actionDriver.clickElement(
        this.commonPage.pageObject.dialogMainViewElementText(
          dialogMainViewName,
          "td",
          values[0],
          Number(values[1])
        )
      );
    } else {
      await global.actionDriver.clickElement(
        this.commonPage.pageObject.dialogMainViewElementText(
          dialogMainViewName,
          "td",
          analysisFieldValue
        )
      );
    }

    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        dialogMainViewName,
        "button",
        "OK"
      )
    );
  }

  /**
   *
   * @param sampleTypeName it can have in format given: sampleTypeName;state~sampleTypeName;state
   * COOLANT;Assign~FUEL;Unassign
   */
  async selectSampleType(sampleTypeName: string, dialogMainViewName: string) {
    do {
      await global.actionDriver.clickElement(
        this.commonPage.pageObject.formFieldWithIcon(
          "div",
          "Sample Type",
          "grip-solid-horizontal"
        )
      );
    } while (
      !(await global.actionDriver.isElementDisplayed(
        this.commonPage.pageObject.tagWithExactText(
          "span",
          "Quick Codes Selection Dialog"
        )
      ))
    );

    if (sampleTypeName.includes("~")) {
      const samplesName = sampleTypeName.split("~");
      for (let i = 0; i < samplesName.length; i++) {
        console.log(`Adding sample type: ${samplesName[i]}`);
        const values = samplesName[i].split(";");
        await global.actionDriver.clickElement(
          this.commonPage.pageObject.dialogMainViewElementText(
            dialogMainViewName,
            "td",
            `${values[0]}   `
          )
        );
        await global.actionDriver.clickElement(
          this.commonPage.pageObject.dialogMainViewElementText(
            dialogMainViewName,
            "button",
            values[1]
          )
        );
        await global.actionDriver.waitForElement(3);
      }
    } else {
      const values = sampleTypeName.split(";");
      await global.actionDriver.clickElement(
        this.commonPage.pageObject.dialogMainViewElementText(
          dialogMainViewName,
          "td",
          `${values[0]}   `
        )
      );
      await global.actionDriver.clickElement(
        this.commonPage.pageObject.dialogMainViewElementText(
          dialogMainViewName,
          "button",
          values[1]
        )
      );
    }

    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        dialogMainViewName,
        "button",
        "OK"
      )
    );
  }

  async selectConfigureOptions(configureOptionName: string) {
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.buttonWithText("Configure...")
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Select Dialog",
        "td",
        configureOptionName
      )
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Select Dialog",
        "button",
        "OK"
      )
    );
  }

  async addRenameComponent(addRenameOperation: string, componentName: string) {
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Components Dialog",
        "button",
        `${addRenameOperation}...`
      )
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        "Prompt Dialog",
        "input",
        "id",
        "field"
      ),
      componentName
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Prompt Dialog",
        "button",
        "OK"
      )
    );
  }
  /**
   *
   * @param checkboxName -can have value like-
   * displayed=Displayed,
   * attributes=Has Attributes,
   * allowCancel=Allow Cancel,
   * reportable=Reportable,
   * optional=Optional,
   * instrument=Uses Instr.
   * @param status can have values like true or false
   */
  async selectComponentCheckbox(status: string, checkboxName: string) {
    if (status === "checked") {
      if (
        (await global.actionDriver.isElementSelected(
          this.commonPage.pageObject.dialogMainViewElementAttribute(
            "Components Dialog",
            "input",
            "name",
            checkboxName
          )
        )) === false
      ) {
        await global.actionDriver.clickElement(
          this.commonPage.pageObject.dialogMainViewElementAttribute(
            "Components Dialog",
            "input",
            "name",
            checkboxName
          )
        );
      }
    } else {
      if (
        (await global.actionDriver.isElementSelected(
          this.commonPage.pageObject.dialogMainViewElementAttribute(
            "Components Dialog",
            "input",
            "name",
            checkboxName
          )
        )) === true
      ) {
        await global.actionDriver.clickElement(
          this.commonPage.pageObject.dialogMainViewElementAttribute(
            "Components Dialog",
            "input",
            "name",
            checkboxName
          )
        );
      }
    }
  }

  async selectComponentConfigureDataType(dataType: string) {
    await this.commonPage.selectDialogMainViewComboboxDropdown(
      "Components Dialog",
      "typePane",
      dataType
    );
  }

  /**
   * dialogMainViewName-Numeric Properties Dialog=Numeric | Calculated Properties Dialog=Calculated
   * @param componentName
   * @param aliasName
   * @param units
   * @param roundResultValue
   * @param decimalPlaces
   * @param sigFigs
   * @param formatCalculation
   */
  async addComponentNumericOrCalculatedProperties(
    dialogMainViewName: string,
    componentName: string,
    aliasName: string,
    units: string,
    roundResultValue: string,
    decimalPlaces: string,
    sigFigs: string,
    formatCalculation: string
  ) {
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Components Dialog",
        "td",
        componentName
      )
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Components Dialog",
        "button",
        "Properties..."
      )
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        `${dialogMainViewName} Properties Dialog`,
        "input",
        "id",
        "alias"
      ),
      aliasName
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        `${dialogMainViewName} Properties Dialog`,
        "input",
        "id",
        "units"
      ),
      units
    );
    await this.commonPage.selectDialogMainViewComboboxDropdown(
      `${dialogMainViewName} Properties Dialog`,
      "rounding",
      roundResultValue
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        `${dialogMainViewName} Properties Dialog`,
        "input",
        "id",
        "places"
      ),
      decimalPlaces
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        `${dialogMainViewName} Properties Dialog`,
        "input",
        "id",
        "places2"
      ),
      sigFigs
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        `${dialogMainViewName} Properties Dialog`,
        "input",
        "id",
        "formatCalc"
      ),
      formatCalculation
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        `${dialogMainViewName} Properties Dialog`,
        "button",
        "OK"
      )
    );
  }

  async addComponentListProperties(
    componentName: string,
    aliasName: string,
    listName: string,
    formatCalculation: string
  ) {
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Components Dialog",
        "td",
        componentName
      )
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Components Dialog",
        "button",
        "Properties..."
      )
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        "List Properties Dialog",
        "input",
        "id",
        "alias"
      ),
      aliasName
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        "List Properties Dialog",
        "input",
        "id",
        "list"
      ),
      listName
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        "List Properties Dialog",
        "input",
        "id",
        "formatCalc"
      ),
      formatCalculation
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "List Properties Dialog",
        "button",
        "OK"
      )
    );
  }

  async addComponentTextProperties(
    componentName: string,
    aliasName: string,
    formatCalculation: string
  ) {
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Components Dialog",
        "td",
        componentName
      )
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Components Dialog",
        "button",
        "Properties..."
      )
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        "Text Component Properties",
        "input",
        "id",
        "alias"
      ),
      aliasName
    );

    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        "Text Component Properties",
        "input",
        "id",
        "formatCalc"
      ),
      formatCalculation
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Text Component Properties",
        "button",
        "OK"
      )
    );
  }

  /**
   *
   * @param componentName
   * @param moveUpDown - Move Up or Move Down
   */
  async changeComponentOrder(componentName: string, moveUpDown: string) {
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Components Dialog",
        "td",
        componentName
      )
    );
    const orderValue = moveUpDown.split(";");
    for (let i = 0; i < Number(orderValue[1]); i++) {
      await global.actionDriver.clickElement(
        this.commonPage.pageObject.dialogMainViewElementText(
          "Components Dialog",
          "button",
          orderValue[0]
        )
      );
    }
  }

  async openExistingAnalysis(analysisName: string) {
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.tagWithAttribute("img", "title", "Open Entry")
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        "Browser",
        "input",
        "id",
        "Entry"
      ),
      analysisName
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Browser",
        "button",
        "OK"
      )
    );
  }

  async deleteExistingAnalysis(analysisName: string) {
    this.openExistingAnalysis(analysisName);
  }

  async configureUsersGroupName(groupName: string,userName: string) {
    await this.openTable("Users");
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.tagWithAttribute("img", "title", "Open Entry")
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        "Browser",
        "input",
        "id",
        "Entry"
      ),
      userName
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Browser",
        "button",
        "OK"
      )
    );
    await this.commonPage.comboboxDropdown(
      "div",
      "Group Name",
      "combobox-dropdown",
      groupName
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.tagWithAttribute("img", "title", "Save")
    );
  }
}
