import { FactoryRegistries } from "../factory/factoryRegistry";
import { DateManager } from "../utilities/dateManager";
import { FileHandler } from "../utilities/fileHandler";

export class FolderManagerPage {
  private commonPage = FactoryRegistries.getCommonPage();

  pageObject = {
    sampleTestArrow: (sampleTestName: string) =>`(//table[contains(@title,'${sampleTestName}')]//img)[1]`,
    sampleTestChildTextValue: (parentTestName: string, childIndex: string) =>
      `(//table[contains(@title,'${parentTestName}')]/following-sibling::div/table/tbody/tr/td[5])[${childIndex}]`,
    analysisUnderEditTests: (analysisName: string,index=1) =>
      `//a[text()='Analysis']/following::td[text()='${analysisName}'][${index}]`,
    analysisStatusUnderEditTests: (analysisName: string) =>
      `${this.pageObject.analysisUnderEditTests(
        analysisName
      )}/following::td[2]`,
    analysisReplicateUnderEditTests: (analysisName: string) =>
      `${this.pageObject.analysisUnderEditTests(
        analysisName
      )}/following::td[1]`,
      sampleTestCheckBox: (sampleTestName: string) => `//div[contains(text(),'${sampleTestName}')]//parent::td//preceding-sibling::td[1]`,
      analysisUnderSample: (sampleTestName: string, analysisName:string) => `//div[contains(text(),'${sampleTestName}')]//ancestor::table//following-sibling::div[1]//td/div[contains(text(), '${analysisName}')]`,  
      multiSelectTestCheckBoxByIndex: (index: string) =>
      `(//table[contains(@class, 'gridTableInner')]//input[@type='checkbox'])[${index}]`,
      analysisUnderSampleByIndex: (sampleTestName: string, analysisName: string, analysisIndex: string, analysisCellIndex:string) => `(//div[contains(text(),'${sampleTestName}')]//ancestor::table//following-sibling::div[1]//td/div[contains(text(), '${analysisName}')])[${analysisIndex}]//parent::td//preceding-sibling::td[${analysisCellIndex}]`,
      componentUnderSampleAnalysisByIndex: (sampleTestName: string, analysisName: string, analysisIndex: string, componentCellIndex: string) => `(//div[contains(text(),'${sampleTestName}')]//ancestor::table//following-sibling::div[1]//td/div[contains(text(), '${analysisName}')])[${analysisIndex}]//ancestor::table//following-sibling::div//td[${componentCellIndex}]`,
      columnsOfAdjustableTable: `(//table[contains(@class, 'gridTableHeader')])[2]//td/span`,
      rowsOfNotAdjustableTableTextId: `(//table[contains(@class, 'gridTableInner')])[1]//tr//td[3]`,
      cellByColAndRowIndex: (rowIndex: string|number, colIndex: string|number) => `(//table[contains(@class, 'gridTableInner')])[2]//tr[${rowIndex}]//td[${colIndex}]`,
      textAreaCodeMirror: `//div[contains(@class, 'CodeMirror')]//textarea`
  };

  async createNewFolder(
    folderName: string,
    templateName: string,
    ownerName: string,
    description: string
  ) {
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.tagWithAttribute("img", "title", "New")
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        "Create Folder",
        "input",
        "id",
        "name"
      ),
      folderName
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        "Create Folder",
        "input",
        "id",
        "template"
      ),
      templateName
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        "Create Folder",
        "input",
        "id",
        "owner"
      ),
      ownerName
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        "Create Folder",
        "textarea",
        "id",
        "description"
      ),
      description
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Create Folder",
        "button",
        "OK"
      )
    );
  }
  async selectDateRangeFromComboboxDropdown(dateRangeValue: string) {
    await this.commonPage.selectDialogMainViewComboboxDropdown(
      "Date Range Prompter",
      "field",
      dateRangeValue
    );
  }

  async enterStartEndDate(startDateValue: string, endDateValue: string) {
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        "Date Range Prompter",
        "input",
        "id",
        "startDate"
      ),
      await DateManager.getDaysOut(Number(startDateValue), "MMM/DD/YYYY")
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        "Date Range Prompter",
        "input",
        "id",
        "endDate"
      ),
      await DateManager.getDaysOut(Number(endDateValue), "MMM/DD/YYYY")
    );
  }

  /**
   *
   * @param sampleTypeName this can single value like OIL,ALL,etc..
   * This can have multiple values like [OIL,COOLANT]
   */
  async selectSampleTypeForFolder(sampleTypeName: string) {
    if (sampleTypeName !== "ALL") {
      if (sampleTypeName.includes(",")) {
        const sampleValues = sampleTypeName.split(",");
        for (let i = 0; i < sampleValues.length; i++) {
          await global.actionDriver.controlClickElement(
            this.commonPage.pageObject.dialogMainViewElementText(
              "Select Dialog",
              "td",
              sampleValues[i]
            )
          );
        }
      } else {
        await global.actionDriver.clickElement(
          this.commonPage.pageObject.dialogMainViewElementText(
            "Select Dialog",
            "td",
            sampleTypeName
          )
        );
      }
    } else {
      await global.actionDriver.clickElement(
        this.commonPage.pageObject.dialogMainViewElementText(
          "Select Dialog",
          "button",
          "Select All"
        )
      );
    }
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Select Dialog",
        "button",
        "OK"
      )
    );
  }

  async addAnalysisInFolder(analysisName: string, analysisType: string) {
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.buttonWithText("Add Analysis...")
    );
    await this.commonPage.selectDialogMainViewComboboxDropdown(
      "Choose Analysis Dialog",
      "types",
      analysisType
    );

    if (analysisName.includes(",")) {
      const values = analysisName.split(",");
      for (let i = 0; i < values.length; i++) {
        await global.actionDriver.controlClickElement(
          this.commonPage.pageObject.dialogMainViewElementText(
            "Choose Analysis Dialog",
            "td",
            values[i]
          )
        );
      }
    } else {
      await global.actionDriver.clickElement(
        this.commonPage.pageObject.dialogMainViewElementText(
          "Choose Analysis Dialog",
          "td",
          analysisName
        )
      );
    }

    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Choose Analysis Dialog",
        "button",
        "OK"
      )
    );
  }

  async openCreatedFolder(folderName: string) {
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.tagWithAttribute("img", "title", "Open")
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.dialogMainViewElementAttribute(
        "Folder Prompt Dialog",
        "input",
        "id",
        "dbEntryField"
      ),
      folderName
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Folder Prompt Dialog",
        "button",
        "OK"
      )
    );
  }

  async addRemoveGroupObjects(addRemoveProperty:string,multiSelectOptionsName: string) {
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.menuBar("taskMenuBar", "Edit")
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.subMenuBar("Group Objects")
    );
    if (multiSelectOptionsName.includes(",")) {
      const values = multiSelectOptionsName.split(",");
      for (let i = 0; i < multiSelectOptionsName.length; i++) {
        await global.actionDriver.controlClickElement(
          this.commonPage.pageObject.dialogMainViewElementText(
            "Multi-Select",
            "td",
            values[i]
          )
        );
      }
    } else {
      await global.actionDriver.controlClickElement(
        this.commonPage.pageObject.dialogMainViewElementText(
          "Multi-Select",
          "td",
          multiSelectOptionsName
        )
      );
    }

    if(addRemoveProperty==="add"){
      await global.actionDriver.clickElement(
        this.commonPage.pageObject.dialogMainViewElementText(
          "Multi-Select",
          "button",
          ">>>"
        )
      );
    }else{
      await global.actionDriver.clickElement(
        this.commonPage.pageObject.dialogMainViewElementText(
          "Multi-Select",
          "button",
          "<<<"
        )
      );

    }
    
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Multi-Select",
        "button",
        "OK"
      )
    );
  }

  async selectDealersFromMultiSelect(dealersName:string){
    if (dealersName !== "ALL") {
      if (dealersName.includes(",")) {
        const dealerValues = dealersName.split(",");
        for (let i = 0; i < dealerValues.length; i++) {
          await global.actionDriver.controlClickElement(
            this.commonPage.pageObject.dialogMainViewElementText(
              "Multi-Select",
              "td",
              dealerValues[i]
            )
          );
        }
      } else {
        await global.actionDriver.clickElement(
          this.commonPage.pageObject.dialogMainViewElementText(
            "Multi-Select",
            "td",
            dealersName
          )
        );
      }
    } else {
      await global.actionDriver.clickElement(
        this.commonPage.pageObject.dialogMainViewElementText(
          "Multi-Select",
          "button",
          "All"
        )
      );
    }
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Multi-Select",
        "button",
        "OK"
      )
    );

  }

  async cellLocatorByColAndRowForFrozenPaneTable(column: string, row: string) {
    const rows = await global.actionDriver.getWebElements(this.pageObject.rowsOfNotAdjustableTableTextId);
    const columns = await global.actionDriver.getWebElements(this.pageObject.columnsOfAdjustableTable);
    let rowIndex = 0;
    let columnIndex = 0;
    for (let i = 0; i < rows.length; i++) {
      const element = rows[i];
      const text = await element.textContent();
      const rowVal = await FileHandler.getKeyValue(row) || row;
      console.log(`rowVal:: ${rowVal}|`);
      console.log(`rowText:: ${text}|`);
      if(rowVal==text.trim()) {
        rowIndex=i+1;
        break;
      }
    }

    for (let i = 0; i < columns.length; i++) {
      const element = columns[i];
      const text = await element.textContent();
      const columnVal = await FileHandler.getKeyValue(column) || column;
      console.log(`columnVal:: ${columnVal}|`);
      console.log(`columnText:: ${text}|`);
      if(columnVal==text.trim()) {
        columnIndex=i+1;
        break;
      }
    }
   return this.pageObject.cellByColAndRowIndex(rowIndex,columnIndex);
  }

  async verifyObjectGroupPropertyData(propertyName:string,propValues:string,sampleName:string){
    await global.actionDriver.clickElement(this.pageObject.sampleTestArrow(`${propertyName}: ${await FileHandler.getKeyValue(propValues) || propValues}`));
    await global.actionDriver.waitForElement(3);
    const isVisible = await global.actionDriver.isElementDisplayed(
      this.commonPage.pageObject.tagWithAttribute(
        "table",
        "title",
        (await FileHandler.getKeyValue(sampleName)) || sampleName
      )
    );
    global.expect_(isVisible).to.be.equal(true);
  }
  
}
