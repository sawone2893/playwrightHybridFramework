import { FactoryRegistries } from "../factory/factoryRegistry";

export class ResultEntryPage {
  private commonPage = FactoryRegistries.getCommonPage();
  pageObject = {
    resultEntryAnalysisName:(analysisName:string,index=1)=>`//div[contains(@id,'testListPane')]//a[text()='Analysis']/following::td[text()='${analysisName}'][${index}]`,
    componentValue:(componentName:string)=>`//td[text()='${componentName}' and @nowrap='true']/following-sibling::td[5]`
  };
}
