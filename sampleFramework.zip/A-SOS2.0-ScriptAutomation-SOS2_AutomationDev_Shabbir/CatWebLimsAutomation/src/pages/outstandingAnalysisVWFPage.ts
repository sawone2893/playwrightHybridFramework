import { FactoryRegistries } from "../factory/factoryRegistry";
import { DateManager } from "../utilities/dateManager";
import { FileHandler } from "../utilities/fileHandler";

export class OutstandingAnalysisVWFPage {
  private commonPage = FactoryRegistries.getCommonPage();
  pageObject = {
    /** @param editSetType -this can have value like Sample Type or Analysis */
    sampleTypeAnalaysisEditSetBtn: (editSetType: string) =>
      `//button[contains(text(),'${editSetType} Set')]/following::button[contains(text(),'Edit Sets')][1]`,
      outstandingAnalysisTableData:(rowNum:string,colNum:string)=>`//td[contains(@data-vw_cellid,'WORK_ANALYSIS::VW_WORK_AN') and @data-vw_rownumber=${rowNum} and @data-vw_colnumber =${colNum}]`,
      outstandingAnalysisTableDataAnchorLink:(rowNum:string,colNum:string)=>`${this.pageObject.outstandingAnalysisTableData(rowNum,colNum)}/a`
  
  };

  async performEditSetForSampleTypeOrAnalysis(
    editSetType: string,
    setName: string,
    sampleTypeAnalysisNames: string
  ) {
    
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Information",
        "button",
        setName
      )
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.formFieldWithIcon(
        "div",
        `${editSetType} Selection`,
        "grip-solid-horizontal"
      )
    );
    if (sampleTypeAnalysisNames.includes("~")) {
      const sampleTypeAnalysis = sampleTypeAnalysisNames.split("~");
      for (let i = 0; i < sampleTypeAnalysis.length; i++) {
        const values = sampleTypeAnalysis[i].split(";");
        if(editSetType==="Analysis"){
          await global.actionDriver.clickElement(
            this.commonPage.pageObject.dialogMainViewElementText(
              "Quick Codes Selection Dialog",
              "td",
              `${await FileHandler.getKeyValue(values[0].split(" ")[0]) || values[0].split(" ")[0]}   ${await FileHandler.getKeyValue(values[0].split(" ")[1]) || values[0].split(" ")[1]}`
            )
          );
        }else{
          await global.actionDriver.clickElement(
            this.commonPage.pageObject.dialogMainViewElementText(
              "Quick Codes Selection Dialog",
              "td",
              `${values[0]}   `
            )
          );

        }
        await global.actionDriver.clickElement(
          this.commonPage.pageObject.dialogMainViewElementText(
            "Quick Codes Selection Dialog",
            "button",
            values[1]
          )
        );
        await global.actionDriver.waitForElement(3);
      }
    } else {
      const values = sampleTypeAnalysisNames.split(";");
      if(editSetType==="Analysis"){
        await global.actionDriver.clickElement(
          this.commonPage.pageObject.dialogMainViewElementText(
            "Quick Codes Selection Dialog",
            "td",
            `${await FileHandler.getKeyValue(values[0].split(" ")[0]) || values[0].split(" ")[0]}   ${await FileHandler.getKeyValue(values[0].split(" ")[1]) || values[0].split(" ")[1]}`
          )
        );
      }else{
        await global.actionDriver.clickElement(
          this.commonPage.pageObject.dialogMainViewElementText(
            "Quick Codes Selection Dialog",
            "td",
            `${values[0]}   `
          )
        );
      }
      await global.actionDriver.clickElement(
        this.commonPage.pageObject.dialogMainViewElementText(
          "Quick Codes Selection Dialog",
          "button",
          values[1]
        )
      );
    }

    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Quick Codes Selection Dialog",
        "button",
        "OK"
      )
    );

    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        `Select ${editSetType}`,
        "button",
        "OK"
      )
    );
  }

  /**
   * 
   * @param rowsData -date,All,ANA1,ANA2...:0,1,2,2~2,5,6,2,4
   */
  async validateOutsandingAnalysisTableData(rowsData:string){
    let value:any;
    if(rowsData.includes("~")){
      const rowData=rowsData.split("~");
      for(let i=0;i<rowData.length;i++){
        const singleRow=rowData[i].split(",");
        value=await DateManager.getDaysOut(Number(singleRow[0]), "DD-MMM-YY");
            const rowNum=await global.actionDriver.getAttributeValue(this.commonPage.pageObject.tagWithExactText("td",value),"data-vw_rownumber");
            const colNum=await global.actionDriver.getAttributeValue(this.commonPage.pageObject.tagWithExactText("td",value),"data-vw_colnumber");
        for(let j=1;j<singleRow.length;j++){
        global.expect_(await global.actionDriver.getElementText(this.pageObject.outstandingAnalysisTableDataAnchorLink(rowNum,(Number(colNum)+j).toString()))).to.be.equal(singleRow[j]);
        } 
    }
  }else{
    const singleRow=rowsData.split(",");
    value=await DateManager.getDaysOut(Number(singleRow[0]), "DD-MMM-YY");
        const rowNum=await global.actionDriver.getAttributeValue(this.commonPage.pageObject.tagWithExactText("td",value),"data-vw_rownumber");
        const colNum=await global.actionDriver.getAttributeValue(this.commonPage.pageObject.tagWithExactText("td",value),"data-vw_colnumber");
    for(let j=1;j<singleRow.length;j++){
    global.expect_(await global.actionDriver.getElementText(this.pageObject.outstandingAnalysisTableDataAnchorLink(rowNum,(Number(colNum)+j).toString()))).to.be.equal(singleRow[j]);
    } 
  }
}
}
