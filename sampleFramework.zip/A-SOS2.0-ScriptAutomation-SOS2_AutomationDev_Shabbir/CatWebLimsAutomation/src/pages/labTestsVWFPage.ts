import { FactoryRegistries } from "../factory/factoryRegistry";
import { DateManager } from "../utilities/dateManager";

export class LabTestsVWFPage {
  private commonPage = FactoryRegistries.getCommonPage();
  pageObject = {
    labTestTableData:(rowNum:string,colNum:string)=>`//td[contains(@data-vw_cellid,'LAB_TESTS::LAB_TESTS_TABLE') and @data-vw_rownumber=${rowNum} and @data-vw_colnumber =${colNum}]`,
    labTestTableDataAnchorLink:(rowNum:string,colNum:string)=>`${this.pageObject.labTestTableData(rowNum,colNum)}/a`
  };

  /**
   * 
   * @param dealersNames this can have values in the format like B030   ALTORFER INC.;Assign~D600   PIPELINE MACHINERY;Assign
   */
  async selectDealersFromSampleCriteria(dealersNames: string) {
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.formFieldWithIcon(
        "div",
        "Select the Dealer(s)",
        "grip-solid-horizontal"
      )
    );
    if (dealersNames.includes("~")) {
      const dealersName = dealersNames.split("~");
      for (let i = 0; i < dealersName.length; i++) {
        console.log(`Adding sample type: ${dealersName[i]}`);
        const values = dealersName[i].split(";");
        await global.actionDriver.clickElement(
          this.commonPage.pageObject.dialogMainViewElementText(
            "Quick Codes Selection Dialog",
            "td",
            `${values[0]}   `
          )
        );
        await global.actionDriver.clickElement(
          this.commonPage.pageObject.dialogMainViewElementText(
            "Quick Codes Selection Dialog",
            "button",
            values[1]
          )
        );
        await global.actionDriver.waitForElement(3);
      }
    } else {
      const values = dealersNames.split(";");
      await global.actionDriver.clickElement(
        this.commonPage.pageObject.dialogMainViewElementText(
          "Quick Codes Selection Dialog",
          "td",
          `${values[0]}   `
        )
      );
      await global.actionDriver.clickElement(
        this.commonPage.pageObject.dialogMainViewElementText(
          "Quick Codes Selection Dialog",
          "button",
          values[1]
        )
      );
    }

    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Quick Codes Selection Dialog",
        "button",
        "OK"
      )
    );
  }

  async enterStartEndDate(startDateValue: string, endDateValue: string) {
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.textField("div", `Start Date:`),
      await DateManager.getDaysOut(Number(startDateValue), "MMM/DD/YYYY")
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.textField("div", `End Date:`),
      await DateManager.getDaysOut(Number(endDateValue), "MMM/DD/YYYY")
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Select Sample Criteria",
        "button",
        "OK"
      )
    );
  }

}
