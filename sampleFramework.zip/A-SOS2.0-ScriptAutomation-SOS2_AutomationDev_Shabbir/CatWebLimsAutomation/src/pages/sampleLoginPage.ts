import { FactoryRegistries } from "../factory/factoryRegistry";
import { randomNum } from "../utilities/commonUtil";
import { DateManager } from "../utilities/dateManager";
import { FileHandler } from "../utilities/fileHandler";

export class SampleLoginPage {
  private commonPage = FactoryRegistries.getCommonPage();
  pageObject = {
    sampleLoginTemplateId:`//span[text()='Browser']/following::span[contains(text(),'Template Id')]/following::span[contains(@class,'ui-icon-search')]/ancestor::a/preceding-sibling::input`
  };

  async openTemplate(templateIdName: string) {
    await global.actionDriver.waitForElement(2);
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.tagWithAttribute(
        "img",
        "title",
        "Open Template"
      )
    );
    await global.actionDriver.waitForElement(2);
    if(await global.actionDriver.getElementsCount(this.pageObject.sampleLoginTemplateId)==1){
      await global.actionDriver.enterTextOnElement(
        this.pageObject.sampleLoginTemplateId,
        templateIdName
      );
    }else{
      await global.actionDriver.enterTextOnElement(
        `(${this.pageObject.sampleLoginTemplateId})[2]`,
        templateIdName
      );
    }
    
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Browser",
        "button",
        "OK"
      )
    );
  }

  /**
   *
   * @param templateFieldValuedetails format can be as Dealer,B030~Lab,A100~Text Id,SAMPLE1AUTO1~Process Date,0~Sample Type,OIL~Equipement Component,XYZ~Serial Number,123456~Equipment Number,4234234
   */
  async enterSampleLoginTemplateSummaryDetails(
    templateFieldValuedetails: string
  ) {
    const templateFieldValues = templateFieldValuedetails.split("~");
    for (let i = 0; i < templateFieldValues.length; i++) {
      const fieldValue = templateFieldValues[i].split(",");
      if (
        fieldValue[0].includes("Lab") ||
        fieldValue[0] === "Group Name"
      ) {
        await this.commonPage.comboboxDropdown(
          "div",
          fieldValue[0],
          "combobox-dropdown",
          fieldValue[1]
        );
      } else if (
        fieldValue[0] === "Sample Type" ||
        fieldValue[0] === "Priority"
      ) {
        await this.commonPage.comboboxDropdown(
          "div",
          fieldValue[0],
          "userlist-dropdown",
          fieldValue[1]
        );
      } else if (fieldValue[0] === "Text Id") {
        const textId = `${fieldValue[1]}_${randomNum()}`;
        await FileHandler.setKeyValue(fieldValue[1], textId);
        await global.actionDriver.enterTextOnElement(
          this.commonPage.pageObject.textField("div", `${fieldValue[0]}:`),
          textId
        );
      }else {
        if (fieldValue[0].includes("Date")) {
          fieldValue[1] = await DateManager.getDaysOut(
            Number(fieldValue[1]),
            "MMM/DD/YYYY"
          );
        }
        await global.actionDriver.enterTextOnElement(
          this.commonPage.pageObject.textField("div", `${fieldValue[0]}:`),
          fieldValue[1]
        );
      }
    }
    //Generating registration id randomly.
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.textField("div", `Registration Id:`),
      `${randomNum(6)}`
    );
  }

  async editTestsAddReplicates(
    noOfReplicates: string,
    sampleName: string,
    testAnalysisName: string
  ) {
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        `Test Editor : ${sampleName}`,
        "td",
        `${testAnalysisName}`
      )
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        `Test Editor : ${sampleName}`,
        "button",
        "Add Replicate(s)..."
      )
    );
    await global.actionDriver.enterTextOnElement(
      this.commonPage.pageObject.textField("span", "Number of replicates:"),
      noOfReplicates
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        "Integer Prompter",
        "button",
        "OK"
      )
    );
    await global.actionDriver.clickElement(
      this.commonPage.pageObject.dialogMainViewElementText(
        `Test Editor : ${sampleName}`,
        "button",
        "OK"
      )
    );
  }
}
