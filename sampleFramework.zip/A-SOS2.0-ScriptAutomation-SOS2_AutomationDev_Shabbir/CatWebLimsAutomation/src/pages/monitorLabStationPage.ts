import { FactoryRegistries } from "../factory/factoryRegistry";

export class MonitorLabStationPage{
    private commonPage = FactoryRegistries.getCommonPage();
    pageObject = {
        monitorLabStationTableCols:(tableName:string,colTagName:string,colName:string)=>`//span[text()='${tableName}']/following::${colTagName}[contains(text(),'${colName}')][1]`,
    };
}