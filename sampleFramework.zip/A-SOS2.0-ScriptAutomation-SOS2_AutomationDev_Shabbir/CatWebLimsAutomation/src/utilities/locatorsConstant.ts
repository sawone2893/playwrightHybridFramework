export const LocatorsConstant={
    //CommonPage Locator Identifier:
    "TagWithAttribute":"commonPage.pageObject.tagWithAttribute",
    "ButtonWithText":"commonPage.pageObject.buttonWithText",
    "TagWithText":"commonPage.pageObject.tagWithText",
    "TagWithExactText":"commonPage.pageObject.tagWithExactText",
    "MenuBarOption":"commonPage.pageObject.menuBarOption",
    "TabControl":"commonPage.pageObject.tabControl",
    "TagWithPartialAttribute":"commonPage.pageObject.tagWithPartialAttribute",
    "TextField":"commonPage.pageObject.textField",
    "DialogMainViewElementText":"commonPage.pageObject.dialogMainViewElementText",
    "DialogMainViewElementTextWithContains":"commonPage.pageObject.dialogMainViewElementTextWithContains",
    "DialogMainViewElementAttribute":"commonPage.pageObject.dialogMainViewElementAttribute",
    "PopUpMessageText":"commonPage.pageObject.popUpMessageText",
    "ComboboxDropdownOptionWithEcparentcomp":"commonPage.pageObject.comboboxDropdownOptionWithEcparentcomp",
    "DropdownOptionWithFieldName":"commonPage.pageObject.dropdownOptionWithFieldName",
    "FormFieldWithIcon":"commonPage.pageObject.formFieldWithIcon",
    "CheckBoxOrRadioButtonField":"commonPage.pageObject.checkBoxOrRadioButtonField",
    "RadioButtonWithFieldName":"commonPage.pageObject.radioButtonWithFieldName",
    "MenuBar":"commonPage.pageObject.menuBar",
    "SubMenuBar":"commonPage.pageObject.subMenuBar",
    "TableCellValue":"commonPage.pageObject.tableCellValue",
    "AnyFieldWithFormLabel": "commonPage.pageObject.anyFieldWithFormLabel",
    "Spinner": "commonPage.pageObject.spinner",
    "IFrameWorkFlow": "commonPage.pageObject.iFrameWorkFlow",
    "SelectedOption" : "commonPage.pageObject.selectedOption",

    //AnalysisPage Locator Identifier
    //FolderManagerPage Locators Identifier
    "SampleTestArrow":"folderManagerPage.pageObject.sampleTestArrow",
    "SampleTestCheckBox":"folderManagerPage.pageObject.sampleTestCheckBox",
    "AnalysisUnderSample":"folderManagerPage.pageObject.analysisUnderSample",
    "MultiSelectTestCheckBoxByIndex":"folderManagerPage.pageObject.multiSelectTestCheckBoxByIndex",
    "SampleTestChildTextValue":"folderManagerPage.pageObject.sampleTestChildTextValue",
    "AnalysisUnderEditTests":"folderManagerPage.pageObject.analysisUnderEditTests",
    "AnalysisStatusUnderEditTests":"folderManagerPage.pageObject.analysisStatusUnderEditTests",
    "AnalysisReplicateUnderEditTests":"folderManagerPage.pageObject.analysisReplicateUnderEditTests",
    "AnalysisUnderSampleByIndex": "folderManagerPage.pageObject.analysisUnderSampleByIndex",
    "ComponentUnderSampleAnalysisByIndex": "folderManagerPage.pageObject.componentUnderSampleAnalysisByIndex",
    "TextAreaCodeMirror":"folderManagerPage.pageObject.textAreaCodeMirror",


    //ResultEntryPage Locator Identifier
    "ResultEntryAnalysisName":"resultEntryPage.pageObject.resultEntryAnalysisName",
    "ComponentValue":"resultEntryPage.pageObject.componentValue",
    
    //LabTestPage Locator Identifiers
    "LabTestTableData":"labTestsVWFPage.pageObject.labTestTableData",
    "LabTestTableDataAnchorLink":"labTestsVWFPage.pageObject.labTestTableDataAnchorLink",
    
    //OutstandingAnalysisVWFPage Locator Identifiers
    "SampleTypeAnalaysisEditSetBtn":"outstandingAnalysisVWFPage.pageObject.sampleTypeAnalaysisEditSetBtn",
    "OutstandingAnalysisTableData":"outstandingAnalysisVWFPage.pageObject.outstandingAnalysisTableData",
    "OutstandingAnalysisTableDataAnchorLink":"outstandingAnalysisVWFPage.pageObject.outstandingAnalysisTableDataAnchorLink",
    
    //SampleLoginPage Locator Identifiers
    "SampleLoginTemplateId":"sampleLoginPage.pageObject.sampleLoginTemplateId",

    //MonitorLabStationPage Locator Identifiers
    "MonitorLabStationTableCols":"monitorLabStationPage.pageObject.monitorLabStationTableCols",
};