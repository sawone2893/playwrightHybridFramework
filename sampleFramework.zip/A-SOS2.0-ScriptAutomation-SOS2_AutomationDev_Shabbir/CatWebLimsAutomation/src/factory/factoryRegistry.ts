import { TestExecutor } from "../actions/testExecutor";
import { TableManagerPage } from "../pages/tableManagerPage";
import { CommonPage } from "../pages/commonPage";
import { FolderManagerPage } from "../pages/folderManagerPage";
import { SampleLoginPage } from "../pages/sampleLoginPage";
import { ResultEntryPage } from "../pages/resultEntryPage";
import { LabTestsVWFPage } from "../pages/labTestsVWFPage";
import { VisualWorkflowPage } from "../pages/visualWorkflowPage";
import { OutstandingAnalysisVWFPage } from "../pages/outstandingAnalysisVWFPage";
import { MonitorLabStationPage } from "../pages/monitorLabStationPage";

export class FactoryRegistries {
  private static testExecutor_: TestExecutor;
  private static commonPage_: CommonPage;
  private static tableManagerPage_: TableManagerPage;
  private static folderManagerPage_: FolderManagerPage;
  private static sampleLoginPage_: SampleLoginPage;
  private static resultEntry_: ResultEntryPage;
  private static labTestsVWFPage_: LabTestsVWFPage;
  private static visualWorkflowPage_: VisualWorkflowPage;
  private static outstandingAnalysisVWFPage_:OutstandingAnalysisVWFPage;
  private static monitorLabStationPage_:MonitorLabStationPage;

  static getTestExecutor(): TestExecutor {
    if (FactoryRegistries.testExecutor_ === undefined) {
      FactoryRegistries.testExecutor_ = new TestExecutor();
    }
    return FactoryRegistries.testExecutor_;
  }
  static getCommonPage(): CommonPage {
    if (FactoryRegistries.commonPage_ === undefined) {
      FactoryRegistries.commonPage_ = new CommonPage();
    }
    return FactoryRegistries.commonPage_;
  }

  static getTableManagerPage(): TableManagerPage {
    if (FactoryRegistries.tableManagerPage_ === undefined) {
      FactoryRegistries.tableManagerPage_ = new TableManagerPage();
    }
    return FactoryRegistries.tableManagerPage_;
  }

  static getFolderManagerPage(): FolderManagerPage {
    if (FactoryRegistries.folderManagerPage_ === undefined) {
      FactoryRegistries.folderManagerPage_ = new FolderManagerPage();
    }
    return FactoryRegistries.folderManagerPage_;
  }

  static getSampleLoginPage(): SampleLoginPage {
    if (FactoryRegistries.sampleLoginPage_ === undefined) {
      FactoryRegistries.sampleLoginPage_ = new SampleLoginPage();
    }
    return FactoryRegistries.sampleLoginPage_;
  }

  static getResultEntryPage(): ResultEntryPage {
    if (FactoryRegistries.resultEntry_ === undefined) {
      FactoryRegistries.resultEntry_ = new ResultEntryPage();
    }
    return FactoryRegistries.resultEntry_;
  }

  static getLabTestsVWFPage(): LabTestsVWFPage {
    if (FactoryRegistries.labTestsVWFPage_ === undefined) {
      FactoryRegistries.labTestsVWFPage_ = new LabTestsVWFPage();
    }
    return FactoryRegistries.labTestsVWFPage_;
  }
  static getVisualWorkflowPage(): VisualWorkflowPage {
    if (FactoryRegistries.visualWorkflowPage_ === undefined) {
      FactoryRegistries.visualWorkflowPage_ = new VisualWorkflowPage();
    }
    return FactoryRegistries.visualWorkflowPage_;
  }

  static getOutstandingAnalysisVWFPage(): OutstandingAnalysisVWFPage {
    if (FactoryRegistries.outstandingAnalysisVWFPage_ === undefined) {
      FactoryRegistries.outstandingAnalysisVWFPage_ = new OutstandingAnalysisVWFPage();
    }
    return FactoryRegistries.outstandingAnalysisVWFPage_;
  }

  static getMonitorLabStationPage(): MonitorLabStationPage {
    if (FactoryRegistries.monitorLabStationPage_ === undefined) {
      FactoryRegistries.monitorLabStationPage_ = new MonitorLabStationPage();
    }
    return FactoryRegistries.monitorLabStationPage_;
  }
}
