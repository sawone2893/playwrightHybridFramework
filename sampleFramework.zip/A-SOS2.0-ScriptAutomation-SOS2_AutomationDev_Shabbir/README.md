# **GitHub Repositories**


Access to repositories in the Cat Digital GitHub organization will be granted using GitHub Teams.  Specific teams will be granted Read, Write, or Maintain access to repositories based on their usage of the repository.  

The GitHub Team that owns the repository will be granted Write access to the repository.

A sub-team will be created under the GitHub Team to define the code owners.  The Product Owner (PO) and Technical Lead (TL) will be the default members of the code owners sub-team.

A .github/CODEOWNERS file will be created in the repository, defining that all files in the repository are owned by this code owners sub-team.

This sub-team will be granted Maintain access to the repository, allowing these users to manage the branch protection rules.

The repository will be set with Issues, Projects, Wiki, and Workflows/Actions enabled, **however the Platform DevOps team is not supporting these capabilities in 2022.  Therefore, usage of these capabilities is allowed on a ‘use at your own risk’ basis**.

The main/master branch will be configured with the follow default branch protection rules:

Require a pull request before merging

Require at least 1 approval before merging

Dismiss stale pull request approvals when new commits are pushed

Require review from Code Owners (this is based off the CODEOWNERS file created in the repository that is defaulted to have all files in the repository owned by the code owners sub-team).

Restrict who can dismiss PR reviews: set to CODEOWNERS team

Allow specific actors to bypass required pull requests: set to DevOps Engineering team.  NOTE: This is for emergency use in case of expedited change or a tool that the pull request process is dependent on (i.e. Bridgecrew) is down and blocking the team.

Require status checks to pass before merging (specific status checks TBD)

Require conversation resolution before merging

Include administrators (enforces above branch protection rules on administrators)

Allow force pushes: set to CODEOWNERS team

# **Repository Naming Convention**
{Department Prefix}-{Repo Purpose}

ex: P-Azure-Utilities

Note: Repos have a 100 character limit, spaces will be converted to hyphens ( - ).

# **GitHub Team Sub-Team Naming Convention for Code Owners**
{Repository Name}-CodeOwners

ex: P-Azure-Utilities-CodeOwners

# **Repository Security Features**
Be default, the following Code Security & Analysis features will be enabled on all Cat Digital Platform repositories:

Dependency Graph: understand your dependencies

Dependabot Alerts: receive alerts of new vulnerabilities that affect your dependencies

Dependabot Security Updates: easily upgrade to non-vulnerable dependencies

GitHub Advanced Security features (billed per active committer over last 90 days in repo):

Code Scanning: automatically detect common vulnerabilities and coding errors

Secret Scanning: scans repository for known types of secrets
